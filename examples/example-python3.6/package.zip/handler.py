"""handle requests."""

import json
from timeit import default_timer as timer


def lambda_handler(event, context):
    """Handle requests."""
    start = timer()
    durationSeconds = timer() - start

    body = {"durationSeconds": str(durationSeconds)}
    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json"
        },
        "body": json.dumps(body)
    }
